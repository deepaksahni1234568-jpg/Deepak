/*
 * This file is part of ViaFabricPlus - https://github.com/ViaVersion/ViaFabricPlus
 * Copyright (C) 2021-2026 the original authors
 *                         - Florian Reuth <git@florianreuth.de>
 *                         - RK_01/RaphiMC
 * Copyright (C) 2023-2026 ViaVersion and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.viaversion.viafabricplus.features.block.connections;

import com.viaversion.viafabricplus.features.block.interaction.Block1_14;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public interface IBlockStateHandler {
    BlockState connect(final BlockState blockState, final LevelReader levelReader, final BlockPos blockPos);

    default boolean isExceptionForConnection(final BlockState blockState) {
        return blockState.isAir()
            || Block1_14.isExceptBlockForAttachWithPiston(blockState.getBlock())
            || blockState.is(Blocks.MELON)
            || blockState.is(Blocks.PUMPKIN)
            || blockState.is(Blocks.CARVED_PUMPKIN)
            || blockState.is(Blocks.JACK_O_LANTERN)
            || blockState.is(Blocks.BARRIER);
    }
}
