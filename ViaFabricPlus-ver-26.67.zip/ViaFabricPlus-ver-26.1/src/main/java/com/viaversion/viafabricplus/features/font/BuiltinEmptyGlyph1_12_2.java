/*
 * This file is part of ViaFabricPlus - https://github.com/ViaVersion/ViaFabricPlus
 * Copyright (C) 2021-2026 the original authors
 *                         - Florian Reuth <git@florianreuth.de>
 *                         - RK_01/RaphiMC
 * Copyright (C) 2023-2026 ViaVersion and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.viaversion.viafabricplus.features.font;

import com.mojang.blaze3d.textures.GpuTexture;
import net.minecraft.client.gui.font.glyphs.BakedSheetGlyph;
import net.minecraft.client.gui.font.GlyphStitcher;
import com.mojang.blaze3d.font.GlyphInfo;
import com.mojang.blaze3d.font.GlyphBitmap;

public enum BuiltinEmptyGlyph1_12_2 implements GlyphInfo {
    INSTANCE;

    private static final int WIDTH = 0;
    private static final int HEIGHT = 8;

    @Override
    public float getAdvance() {
        return WIDTH;
    }

    public BakedSheetGlyph bake(final GlyphStitcher baker) {
        return baker.stitch(this, new GlyphBitmap() {

            @Override
            public int getPixelWidth() {
                return WIDTH;
            }

            @Override
            public int getPixelHeight() {
                return HEIGHT;
            }

            @Override
            public void upload(final int x, final int y, final GpuTexture texture) {
            }

            @Override
            public float getOversample() {
                return 1F;
            }

            @Override
            public boolean isColored() {
                return true;
            }
        });
    }

}
