/*
 * This file is part of ViaFabricPlus - https://github.com/ViaVersion/ViaFabricPlus
 * Copyright (C) 2021-2026 the original authors
 *                         - Florian Reuth <git@florianreuth.de>
 *                         - RK_01/RaphiMC
 * Copyright (C) 2023-2026 ViaVersion and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.viaversion.viafabricplus.protocoltranslator.impl.command;

import com.viaversion.viafabricplus.screen.impl.SettingsScreen;
import com.viaversion.viaversion.api.command.ViaCommandSender;

public final class SettingsCommand implements VFPSubCommand {

    @Override
    public String name() {
        return "settings";
    }

    @Override
    public String description() {
        return "Opens ViaFabricPlus's configuration/options screen";
    }

    @Override
    public boolean execute(ViaCommandSender sender, String[] args) {
        SettingsScreen.INSTANCE.open(null);
        return true;
    }

}
