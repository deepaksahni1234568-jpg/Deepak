package com.viaversion.viafabricplus.injection.mixin.features.bedrock.inventory;

import com.viaversion.viafabricplus.protocoltranslator.ProtocolTranslator;
import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Types;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.Slot;
import net.raphimc.viabedrock.api.BedrockProtocolVersion;
import net.raphimc.viabedrock.protocol.BedrockProtocol;
import net.raphimc.viabedrock.protocol.ServerboundBedrockPackets;
import net.raphimc.viabedrock.protocol.types.BedrockTypes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractContainerScreen.class)
public abstract class MixinHandledScreen {

    @Inject(method = "slotClicked", at = @At("HEAD"), cancellable = true)
    private void onSlotClicked(Slot slot, int slotId, int mouseButton, 
                               net.minecraft.world.inventory.ClickType type, 
                               CallbackInfo ci) {
        if (!ProtocolTranslator.getTargetVersion()
                .equals(BedrockProtocolVersion.bedrockLatest)) return;

        try {
            final UserConnection connection = 
                ProtocolTranslator.getPlayNetworkUserConnection();

            final PacketWrapper inventoryTransaction = PacketWrapper.create(
                ServerboundBedrockPackets.INVENTORY_TRANSACTION, connection);

            // Legacy transaction type = 0 (normal)
            inventoryTransaction.write(BedrockTypes.UNSIGNED_VAR_INT, 0);
            // actions count = 0 (basic move)
            inventoryTransaction.write(BedrockTypes.UNSIGNED_VAR_INT, 0);

            inventoryTransaction.sendToServer(BedrockProtocol.class);
        } catch (Exception e) {
            // Crash se bachao — silently ignore
        }
    }
}